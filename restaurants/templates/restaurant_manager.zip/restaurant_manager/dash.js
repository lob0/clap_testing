(function() {
  var app = angular.module('dash', []);

  /*
  app.directive("dashHeader", function() {
    return {
      restrict: 'E',
      replace:true,
      templateUrl: "dash-header.html"
    }; 
  });

  app.directive("asideMenu", function() {
    return {
      restrict: 'E',
      replace:true,
      templateUrl: "aside-menu.html",
      controller:function($scope, $location){

        $scope.isSelected = function(route) {
          alert(route);
          return route == $location.path();
        };

      },
      controllerAs:'panel'
    }; 
  });
  
  app.directive("dashboardContent", function() {
    return {
      restrict: 'E',
      replace:true,
      templateUrl: "dashboard-content.html"
    }; 
  });

  app.directive("dashFooter", function() {
    return {
      restrict: 'E',
      replace:true,
      templateUrl: "dash-footer.html"
    }; 
  }); 

  app.directive("detailsContent", function() {
    return {
      restrict: 'E',
      replace:true,
      templateUrl: "details-content.html"
    }; 
  }); 

  app.directive("ementasContent", function() {
    return {
      restrict: 'E',
      replace:true,
      templateUrl: "ementas-content.html"
    }; 
  }); 

  app.directive("galleryContent", function() {
    return {
      restrict: 'E',
      replace:true,
      templateUrl: "gallery-content.html"
    }; 
  }); 

  app.directive("statsContent", function() {
    return {
      restrict: 'E',
      replace:true,
      templateUrl: "stats-content.html"
    }; 
  });  */ 


})();
